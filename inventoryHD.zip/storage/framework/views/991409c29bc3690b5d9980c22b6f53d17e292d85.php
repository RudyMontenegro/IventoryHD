<head>
    <link rel="shortcut icon" href="./images/logoempresa.png" type="image/x-icon" />
</head>
<nav class="navbar navbar-light" style="background-color: #FFCB00;" class="container">
    <div class="row">
        <div class="container-fluid">
            <h1 style="color:#000">LISTA DE USUARIOS</h1>

        </div>
    </div>
    </div>
</nav>



<?php $__env->startSection('seccion'); ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VirtualTecnoDinamyc</title>

</head>

<body>

    <nav class="navbar navbar-expand-lg  bg-light">
        <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-lg btn-block">Volver</a>
    </nav>

    <div class="container-fluid" style="background-color: #FFCB00 ">
        <div>

            <table class="table table-bordered table-responsive text-black">
                <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Correo</th>
                        <th scope="col">Acciones</th>

                    </tr>
                    <?php $__currentLoopData = $dis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dis->name); ?></td>
                        <td><?php echo e($dis->email); ?></td>
                        <td>
                           

                        <a href="<?php echo e(url('editarUsuario',$dis->id)); ?>" class="btn btn-success">Editar</a>
                        
                        
                            <form action="<?php echo e(url('adm/eliminar/'.$dis->id)); ?>" method="post" class="d-inline">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button class="btn btn-danger"
                                    onclick=" return confirm ('¿Esta seguro de Eliminar este Usuario?'); "
                                    type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>

    </div>

</body>
<nav class="navbar navbar-expand-lg  bg-light">
    <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-lg btn-block">Volver</a>
</nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>