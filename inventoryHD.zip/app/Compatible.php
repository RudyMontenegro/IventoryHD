<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compatible extends Model
{
    public $timestamps=false;
}
